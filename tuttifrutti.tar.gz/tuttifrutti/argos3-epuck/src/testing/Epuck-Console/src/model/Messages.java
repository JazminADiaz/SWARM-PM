package model;

public class Messages {
	
	//private ConcurrentHashMap<Integer,String> map = new ConcurrentHashMap<Integer, String>();
	
	public Messages() {
		
	}

	public synchronized void setMessage(int toId, int fromId) {
		
	}
	
	public synchronized String getMessage(int id) {
		return "";
	}
	
	public void addServerThread(int id) {
		
	}
}
